/*global define*/
define( [

	//Todo: check if this is really needed at the end before publishing
], function () {
	'use strict';



} );
